/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-avx2.h"
#include "../common/t2sv_16.c"
